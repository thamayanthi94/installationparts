-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 14, 2022 at 04:43 PM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 7.4.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `installation_parts`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `category_name` varchar(250) NOT NULL,
  `category_image` text NOT NULL,
  `status` int(11) NOT NULL COMMENT '1-Active,2-Inactive,0-Delete',
  `created_datetime` datetime NOT NULL,
  `updated_datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `category_name`, `category_image`, `status`, `created_datetime`, `updated_datetime`) VALUES
(1, 'Carpentery 1', 'uploads/categories/1652524655_food.jpg', 1, '2022-05-14 12:37:48', '2022-05-14 15:47:44'),
(2, 'Carpentery', 'uploads/categories/1652536095_carpentery.jpg', 1, '2022-05-14 15:48:15', '0000-00-00 00:00:00'),
(3, 'Engines', 'uploads/categories/1652537964_istockphoto-1059972498-612x612.jpg', 1, '2022-05-14 16:19:24', '0000-00-00 00:00:00'),
(4, 'pipes', 'uploads/categories/1652538054_pipes.jpg', 1, '2022-05-14 16:20:54', '0000-00-00 00:00:00'),
(5, 'Wheels', 'uploads/categories/1652538155_wheels.jpg', 1, '2022-05-14 16:22:35', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `product_name` varchar(250) NOT NULL,
  `description` text NOT NULL,
  `amount` double(10,2) NOT NULL,
  `currency` varchar(10) NOT NULL,
  `category_id` int(11) NOT NULL,
  `product_img` text NOT NULL,
  `status` int(11) NOT NULL,
  `created_datetime` datetime NOT NULL,
  `updated_datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_name`, `description`, `amount`, `currency`, `category_id`, `product_img`, `status`, `created_datetime`, `updated_datetime`) VALUES
(1, 'Engine Parts', 'lorum ipsum contents parts of enginess', 100.00, '$', 1, 'uploads/products/1652528311_food-images.jpg', 1, '2022-05-14 13:39:12', '2022-05-14 15:46:06'),
(2, 'Brandic cluch discs', 'lorum ipsum contents', 10.00, '$', 1, 'uploads/products/1652530318_carpentery.jpg', 1, '2022-05-14 14:11:58', '0000-00-00 00:00:00'),
(3, 'Vehicale wheels', 'a circular frame or disk arranged to revolve on an axis, as on or in vehicles or machinery', 100.00, '$', 5, 'http://localhost/installation-parts/uploads/products/1652538347_wheels.jpg', 1, '2022-05-14 16:25:47', '0000-00-00 00:00:00'),
(4, 'Exhaust Pipes', 'a tube used to convey water, gas, oil, or other fluid substances.', 5100.00, '$', 4, 'http://localhost/installation-parts/uploads/products/1652538427_wheels.jpg', 1, '2022-05-14 16:27:07', '0000-00-00 00:00:00'),
(5, 'Vehicle Engine', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book', 3000.00, '$', 3, 'http://localhost/installation-parts/uploads/products/1652538512_wheels.jpg', 1, '2022-05-14 16:28:32', '0000-00-00 00:00:00'),
(6, 'Carpentery works', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book', 1000.00, '$', 2, 'http://localhost/installation-parts/uploads/products/1652538545_carpentarty-213.jpg', 1, '2022-05-14 16:29:05', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `reviews`
--

CREATE TABLE `reviews` (
  `id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `ratings` int(11) NOT NULL,
  `comments` text NOT NULL,
  `created_datetime` datetime NOT NULL,
  `updated_datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `reviews`
--

INSERT INTO `reviews` (`id`, `product_id`, `user_id`, `ratings`, `comments`, `created_datetime`, `updated_datetime`) VALUES
(1, 1, 1, 3, 'satisfied work', '2022-05-14 13:50:45', '0000-00-00 00:00:00'),
(2, 3, 2, 5, 'Good', '2022-05-14 16:31:53', '0000-00-00 00:00:00'),
(3, 2, 4, 1, 'Not good', '2022-05-14 16:32:16', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(250) NOT NULL,
  `username` varchar(250) NOT NULL,
  `email` varchar(250) NOT NULL,
  `password` varchar(250) NOT NULL,
  `mobileno` varchar(250) NOT NULL,
  `profile_img` text NOT NULL,
  `status` int(11) NOT NULL,
  `created_datetime` datetime NOT NULL,
  `updated_datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `username`, `email`, `password`, `mobileno`, `profile_img`, `status`, `created_datetime`, `updated_datetime`) VALUES
(1, 'Kalai', 'kalai', 'kalaik123@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '7744112234', 'http://localhost/installation-parts/uploads/users/1652537481_1447169974306.jpeg', 1, '2022-05-14 16:11:21', '0000-00-00 00:00:00'),
(2, 'Malar', 'malar', 'malar94@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '9874563210', '', 1, '2022-05-14 16:12:20', '0000-00-00 00:00:00'),
(3, 'John', 'jone', 'johnpaul@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '9966332255', 'http://localhost/installation-parts/uploads/users/1652537586_confident-doctor-posing-arms-crossed-260nw-716818084.jpg', 1, '2022-05-14 16:13:06', '0000-00-00 00:00:00'),
(4, 'Abdul', 'abdul', 'abdul@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '9632587410', 'http://localhost/installation-parts/uploads/users/1652537644_1631787916.jpg', 1, '2022-05-14 16:14:04', '0000-00-00 00:00:00'),
(5, 'jenifer', 'jeni', 'jenifer@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '9876543210', 'http://localhost/installation-parts/uploads/users/1652537698_1631796006.jpg', 1, '2022-05-14 16:14:58', '0000-00-00 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reviews`
--
ALTER TABLE `reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `reviews`
--
ALTER TABLE `reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
