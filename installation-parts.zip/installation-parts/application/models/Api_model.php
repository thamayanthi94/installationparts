<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class Api_model extends CI_Model 
{
    public function __construct() {
            parent::__construct();
            $this->load->database();
    } 

    public function get_email($email) {
        $this->db->where(array('email' => $email));
        return $this->db->count_all_results('users');
    }

    public function get_mobileno($mobileno) {
        $this->db->where(array('mobileno' => $mobileno));
        return $this->db->count_all_results('users');
    }

    public function get_username($username) {
        $this->db->where(array('username' => $username));
        return $this->db->count_all_results('users');
    }

    public function get_existing_email($id, $email) {
        $this->db->where(array('id!='=>$id, 'email' => $email));
        return $this->db->count_all_results('users');
    }

    public function get_existing_mobileno($id, $mobileno) {
        $this->db->where(array('id!='=>$id, 'mobileno' => $mobileno));
        return $this->db->count_all_results('users');
    }

    public function get_existing_username($id, $username) {
        $this->db->where(array('id!='=>$id, 'username' => $username));
        return $this->db->count_all_results('users');
    }

    public function get_category_name($category_name) {
        $this->db->where(array('category_name' => $category_name));
        return $this->db->count_all_results('categories');
    }

    public function get_existing_category_name($id, $category_name) {
        $this->db->where(array('id!='=>$id, 'category_name' => $category_name));
        return $this->db->count_all_results('categories');
    }

    public function get_category($id) {
        return $this->db->get_where('categories', array('id' => $id))->row()->category_name;
        
    }

     public function get_product_name($id='', $product_name) {
        if(!empty($id)) {
            $this->db->where(array('id!=' => $id));
        }
        $this->db->where(array('product_name' => $product_name));
        return $this->db->count_all_results('products');
    }

    public function get_rating($product_id, $user_id) {
        $this->db->where(array('product_id' => $product_id, 'user_id'=>$user_id));
        return $this->db->count_all_results('reviews');
    }

    public function get_featured_datas() {
        $this->db->select("p.*, u.username, c.category_name,r.ratings,r.comments")
                ->from('products p')
                ->join('categories c', 'c.id = p.category_id', 'LEFT')
                ->join('reviews r', 'r.product_id = p.id', 'LEFT')
                ->join('users u', 'r.user_id = u.id', 'LEFT')
                ->where("p.status = 1")
                ->order_by('r.ratings', 'DESC');
               $product =  $this->db->get();
        $products = $product->result_array();

        return $products;

    }
}