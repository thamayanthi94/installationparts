<?php
defined('BASEPATH') OR exit('No direct script access allowed');

//include Rest Controller library
require APPPATH . '/libraries/REST_Controller.php';

class Installparts extends REST_Controller {

	/* List : GET Method Type 
	   Insert : POST Method Type
	   Update : POST Method Type
	   Delete : POST Method Type
	*/
	public function __construct() {
        parent::__construct();
        $this->load->database();
        $this->load->library('upload');
        $this->load->helpers('url_helper');
        $this->load->model('api_model', 'api');
    }

	/*public function index_get()
	{
		echo 'welcom to install parts'; exit;
	}*/

	/** To Get All User Details */
	public function users_list_get()
	{
		$user_data = array();
		$user_data = $this->post();
		$data = array();
		$users_data = array();
			$users = $this->db->order_by('id', 'DESC')->get_where('users', array('status!='=>0))->result_array();
			//echo '<pre>'; print_r($users); exit;
			foreach($users as $user) {
				$users_data['id'] = $user['id'];
				$users_data['name'] = $user['name'];
				$users_data['username'] = $user['username'];
				$users_data['email'] = $user['email'];
				$users_data['mobileno'] = $user['mobileno'];
				$users_data['profile_img'] = ($user['profile_img'])?base_url().$user['profile_img']:'';

				$user_data[] = $users_data;
			}
		if(!empty($users)) {
			$data = $user_data;
			$response_code = '200';
			$response_message = "Fetched User List";
		} else {
			$response_code = '200';
			$response_message = "User List Not Found";
		}
		$result = $this->data_format($response_code, $response_message, $data);
		$this->response($result, REST_Controller::HTTP_OK);
	}

	/** To Add User Details - POST Method 
	 * @string Name
	 * @string Username
	 * @string Email
	 * @string Password
	 * @var Mobileno
	 * @var Status 
	 * @string Profile Image */
	public function add_user_post()
	{
		$post_data = array();
		$post_data = $this->post();
		$data = array();

		if (!empty($post_data['name']) && !empty($post_data['username']) && !empty($post_data['email']) && $post_data['mobileno'] && $post_data['password'] && $post_data['status']) {

			$get_email = $this->api->get_email($post_data['email']);
			$get_mobileno = $this->api->get_mobileno($post_data['mobileno']);
			$get_username = $this->api->get_username($post_data['username']);
		
			if($get_email == 0) {
				if($get_mobileno == 0) {
					if($get_username == 0) {
						$uploaded_file_name = '';
			            if (isset($_FILES) && isset($_FILES['image']['name']) && !empty($_FILES['image']['name'])) {

			            	if (!is_dir('uploads/users')) {
					            mkdir('./uploads/users', 0777, TRUE);
					        }
			                $table_data1 = [];
				            $configfile['upload_path'] = FCPATH . 'uploads/users';
				            $configfile['allowed_types'] = 'gif|jpg|jpeg|png';
				            $configfile['overwrite'] = FALSE;
				            $configfile['remove_spaces'] = TRUE;
				            $file_name = $_FILES['image']['name'];
				            $configfile['file_name'] = time() . '_' . $file_name;
				            $image_name = $configfile['file_name'];
				            $image_url = 'uploads/users/' . $image_name;
				            $this->upload->initialize($configfile);
				            if ($this->upload->do_upload('image')) {
				                $img_uploadurl = 'uploads/users' . $_FILES['image']['name'];
				                $key = 'user_image';
				                $val = 'uploads/users/' . $image_name;
				                $profile_img = $val;
				            } else {
				            	$profile_img = '';
				            }
			            } else {
			            	$profile_img = '';
			            }

			            $user_data = array(
			            	'name' 		=> $post_data['name'],
							'username' 	=> $post_data['username'],
							'email' 	=> $post_data['email'],
							'mobileno' 	=> $post_data['mobileno'],
							'password' 	=> md5($post_data['password']),
							'profile_img' 	=> ($profile_img)?base_url().$profile_img:'',
							'status' 	=> $post_data['status'],
							'created_datetime' => date('Y-m-d H:i:s')
			            );
						$users = $this->db->insert('users', $user_data);
						if(!empty($users)) {
							$response_code = '200';
							$response_message = "User Details Added Successfully";
						} else {
							$response_code = '200';
							$response_message = "Something went wrong, Please try again";
						}
					} else {
						$response_code = '500';
						$response_message = "Username Already Exists";
					}
				} else {
					$response_code = '500';
					$response_message = "Mobileno Already Exists";
				}
			} else {
				$response_code = '500';
				$response_message = "Email Already Exists";
			}
	} else {
		$response_code = '200';
		$response_message = "Input Field Missing";
	}
		$result = $this->data_format($response_code, $response_message, $data);
		$this->response($result, REST_Controller::HTTP_OK);
	}

	/** To Update User Details - POST Method 
	 * @string Name
	 * @string Username
	 * @string Email
	 * @string Password
	 * @var Mobileno
	 * @var Status 
	 * @string Profile Image */
	public function update_user_post()
	{
		$post_data = array();
		$post_data = $this->post();
		$data = array();

		if (!empty($post_data['id']) && !empty($post_data['name']) && !empty($post_data['username']) && !empty($post_data['email']) && $post_data['mobileno']) {

			$get_existing_email = $this->api->get_existing_email($post_data['id'], $post_data['email']);
			$get_existing_mobileno = $this->api->get_existing_mobileno($post_data['id'], $post_data['mobileno']);
			$get_existing_username = $this->api->get_existing_username($post_data['id'], $post_data['username']);
			$profile_img = $this->db->get_where('users', array('id'=>$post_data['id']))->row()->profile_img;
			if($get_existing_email == 0) {
				if($get_existing_mobileno == 0) {
					if($get_existing_username == 0) {
						$uploaded_file_name = '';
			            if (isset($_FILES) && isset($_FILES['image']['name']) && !empty($_FILES['image']['name'])) {

			            	if (!is_dir('uploads/users')) {
					            mkdir('./uploads/users', 0777, TRUE);
					        }
			                $table_data1 = [];
				            $configfile['upload_path'] = FCPATH . 'uploads/users';
				            $configfile['allowed_types'] = 'gif|jpg|jpeg|png';
				            $configfile['overwrite'] = FALSE;
				            $configfile['remove_spaces'] = TRUE;
				            $file_name = $_FILES['image']['name'];
				            $configfile['file_name'] = time() . '_' . $file_name;
				            $image_name = $configfile['file_name'];
				            $image_url = 'uploads/users/' . $image_name;
				            $this->upload->initialize($configfile);
				            if ($this->upload->do_upload('image')) {
				                $img_uploadurl = 'uploads/users' . $_FILES['image']['name'];
				                $key = 'user_image';
				                $val = 'uploads/users/' . $image_name;
				                $profile_img = $val;
				            } else {
				            	$profile_img = $profile_img;
				            }
			            } else {
			            	$profile_img = $profile_img;
			            }

			            $user_data = array(
			            	'name' 		=> $post_data['name'],
							'username' 	=> $post_data['username'],
							'email' 	=> $post_data['email'],
							'mobileno' 	=> $post_data['mobileno'],
							'profile_img' 	=> ($profile_img)?base_url().$profile_img:'',
			            );
			            $this->db->where('id', $post_data['id']);
						$users = $this->db->update('users', $user_data);
						if(!empty($users)) {
							$response_code = '200';
							$response_message = "User Details Updated Successfully";
						} else {
							$response_code = '200';
							$response_message = "Something went wrong, Please try again";
						}
					} else {
						$response_code = '203';
						$response_message = "Username Already Exists";
					}
				} else {
					$response_code = '203';
					$response_message = "Mobileno Already Exists";
				}
			} else {
				$response_code = '203';
				$response_message = "Email Already Exists";
			}
	} else {
		$response_code = '200';
		$response_message = "Input Field Missing";
	}
		$result = $this->data_format($response_code, $response_message, $data);
		$this->response($result, REST_Controller::HTTP_OK);
	}

	public function data_format($response_code, $response_message, $data) {
        $final_result = array();
        $response = array();
        $response['response_code'] = $response_code;
        $response['response_message'] = $response_message;

        if (!empty($data)) {

            $data = $data;
        } else {

            $data = $data;
        }

        $final_result['response'] = $response;
        $final_result['data'] = $data;

        return $final_result;
    }


    /** To Get All Category Details */
	public function categories_get()
	{
		$post_data = array();
		$post_data = $this->get();
		$data = array();
		$categories_data = array();
			$categories = $this->db->order_by('id','DESC')->get_where('categories', array('status!='=>0))->result_array();
			//echo '<pre>'; print_r($users); exit;
			foreach($categories as $category) {
				$categories_data['id'] = $category['id'];
				$categories_data['category_name'] = $category['category_name'];
				$categories_data['category_image'] = ($category['category_image'])?base_url().$category['category_image']:'';

				$category_data[] = $categories_data;
			}
		if(!empty($categories)) {
			$data = $category_data;
			$response_code = '200';
			$response_message = "Category Listed Successfully";
		} else {
			$response_code = '200';
			$response_message = "Categories List Not Found";
		}
		$result = $this->data_format($response_code, $response_message, $data);
		$this->response($result, REST_Controller::HTTP_OK);
	}

	/** To Add Category Details - POST Method 
	 * @string Category Name
	 * @string CategoryImage
	 * @var Status 
	 */
	public function add_category_post()
	{
		$post_data = array();
		$post_data = $this->post();
		$data = array();

		if (!empty($post_data['category_name']) && !empty($post_data['status'])) {

			$get_category_name = $this->api->get_category_name($post_data['category_name']);
		
			if($get_category_name == 0) {
				$uploaded_file_name = '';
	            if (isset($_FILES) && isset($_FILES['category_image']['name']) && !empty($_FILES['category_image']['name'])) {

	            	if (!is_dir('uploads/categories')) {
			            mkdir('./uploads/categories', 0777, TRUE);
			        }
	                $table_data1 = [];
		            $configfile['upload_path'] = FCPATH . 'uploads/categories';
		            $configfile['allowed_types'] = 'gif|jpg|jpeg|png';
		            $configfile['overwrite'] = FALSE;
		            $configfile['remove_spaces'] = TRUE;
		            $file_name = $_FILES['category_image']['name'];
		            $configfile['file_name'] = time() . '_' . $file_name;
		            $image_name = $configfile['file_name'];
		            $image_url = 'uploads/categories/' . $image_name;
		            $this->upload->initialize($configfile);
		            if ($this->upload->do_upload('category_image')) {
		                $img_uploadurl = 'uploads/categories' . $_FILES['category_image']['name'];
		                $key = 'user_image';
		                $val = 'uploads/categories/' . $image_name;
		                $category_img = $val;
		            } else {
		            	$category_img = '';
		            }
	            } else {
	            	$category_img = '';
	            }

	            $insert_data = array(
	            	'category_name' 		=> $post_data['category_name'],
					'category_image' 	=> ($category_img)?$category_img:'',
					'status' 	=> $post_data['status'],
					'created_datetime' => date('Y-m-d H:i:s')
	            );
				$users = $this->db->insert('categories', $insert_data);
				if(!empty($users)) {
					$response_code = '200';
					$response_message = "Category Added Successfully";
				} else {
					$response_code = '200';
					$response_message = "Something went wrong, Please try again";
				}
					
			} else {
				$response_code = '500';
				$response_message = "Category Name Already Exists";
			}
	} else {
		$response_code = '200';
		$response_message = "Input Field Missing";
	}
		$result = $this->data_format($response_code, $response_message, $data);
		$this->response($result, REST_Controller::HTTP_OK);
	}

	/** To Update Category Details - POST Method 
	 * @string Category Name
	 * @string CategoryImage
	 * @var Status 
	 */
	public function update_category_post()
	{
		$post_data = array();
		$post_data = $this->post();
		$data = array();

		if (!empty($post_data['id']) && !empty($post_data['category_name']) && !empty($post_data['status'])) {

			$get_existing_category_name = $this->api->get_existing_category_name($post_data['id'], $post_data['category_name']);
			
			$category_image = $this->db->get_where('categories', array('id'=>$post_data['id']))->row()->category_image;
			if($get_existing_category_name == 0) {
				$uploaded_file_name = '';
	            if (isset($_FILES) && isset($_FILES['category_image']['name']) && !empty($_FILES['category_image']['name'])) {

	            	if (!is_dir('uploads/categories')) {
			            mkdir('./uploads/categories', 0777, TRUE);
			        }
	                $table_data1 = [];
		            $configfile['upload_path'] = FCPATH . 'uploads/categories';
		            $configfile['allowed_types'] = 'gif|jpg|jpeg|png';
		            $configfile['overwrite'] = FALSE;
		            $configfile['remove_spaces'] = TRUE;
		            $file_name = $_FILES['category_image']['name'];
		            $configfile['file_name'] = time() . '_' . $file_name;
		            $image_name = $configfile['file_name'];
		            $image_url = 'uploads/products/' . $image_name;
		            $this->upload->initialize($configfile);
		            if ($this->upload->do_upload('category_image')) {
		                $img_uploadurl = 'uploads/categories' . $_FILES['category_image']['name'];
		                $val = 'uploads/categories/' . $image_name;
		                $category_img = $val;
		            } else {
		            	$category_img = $category_image;
		            }
	            } else {
	            	$category_img = $category_image;
	            }

	            $update_data = array(
	            	'category_name' 		=> $post_data['category_name'],
					'category_image' 	=> ($category_img)?base_url().$category_img:'',
					'status' 	=> $post_data['status'],
					'updated_datetime' => date('Y-m-d H:i:s')
	            );
	            $this->db->where('id', $post_data['id']);
				$category = $this->db->update('categories', $update_data);
				if(!empty($category)) {
					$response_code = '200';
					$response_message = "Category Details Updated Successfully";
				} else {
					$response_code = '200';
					$response_message = "Something went wrong, Please try again";
				}
			} else {
				$response_code = '203';
				$response_message = "Category Name Already Exists";
			}
		} else {
			$response_code = '200';
			$response_message = "Input Field Missing";
		}
		$result = $this->data_format($response_code, $response_message, $data);
		$this->response($result, REST_Controller::HTTP_OK);
	}

	/** To Get All Category Details */
	public function products_get()
	{
		$post_data = array();
		$post_data = $this->get();
		$data = array();
		$products_data = array();
			$products = $this->db->order_by('id','DESC')->get_where('products', array('status!='=>0))->result_array();

			foreach($products as $product) {
				$category = $this->api->get_category($product['category_id']);
				$products_data['id'] = $product['id'];
				$products_data['product_name'] = $product['product_name'];
				$products_data['description'] = $product['description'];
				$products_data['amount'] = $product['amount'];
				$products_data['currency'] = $product['currency'];
				$products_data['category_name'] = ($category)?$category:'';
				$products_data['product_img'] = ($product['product_img'])?base_url().$product['product_img']:'';
				$products_data['status'] = $product['status'];

				$product_data[] = $products_data;
			}
		if(!empty($products)) {
			$data = $product_data;
			$response_code = '200';
			$response_message = "Products Listed Successfully";
		} else {
			$response_code = '200';
			$response_message = "Products List Not Found";
		}
		$result = $this->data_format($response_code, $response_message, $data);
		$this->response($result, REST_Controller::HTTP_OK);
	}

	/** To Add Product Details - POST Method 
	 * @string Product  Name
	 * @string Description
	 * @var Category Id
	 * @string Product Image
	 * @var Status 
	 */
	public function add_products_post()
	{
		$post_data = array();
		$post_data = $this->post();
		$data = array();

		if (!empty($post_data['product_name']) && !empty($post_data['description'])  && !empty($post_data['category_id']) && !empty($post_data['amount']) && !empty($post_data['currency']) && !empty($post_data['status']) && !empty($_FILES['product_image'])) {

			$get_product_name = $this->api->get_product_name($id='', $post_data['product_name']);
			if($get_product_name == 0) {
				$uploaded_file_name = '';
	            if (isset($_FILES) && isset($_FILES['product_image']['name']) && !empty($_FILES['product_image']['name'])) {

	            	if (!is_dir('uploads/products')) {
			            mkdir('./uploads/products', 0777, TRUE);
			        }
	                $table_data1 = [];
		            $configfile['upload_path'] = FCPATH . 'uploads/products';
		            $configfile['allowed_types'] = 'gif|jpg|jpeg|png';
		            $configfile['overwrite'] = FALSE;
		            $configfile['remove_spaces'] = TRUE;
		            $file_name = $_FILES['product_image']['name'];
		            $configfile['file_name'] = time() . '_' . $file_name;
		            $image_name = $configfile['file_name'];
		            $image_url = 'uploads/categories/' . $image_name;
		            $this->upload->initialize($configfile);
		            if ($this->upload->do_upload('product_image')) {
		                $img_uploadurl = 'uploads/products' . $_FILES['product_image']['name'];
		                $val = 'uploads/products/' . $image_name;
		                $product_img = $val;
		            } else {
		            	$product_img = '';
		            }
	            } else {
	            	$product_img = '';
	            }

	            $insert_data = array(
	            	'product_name' 	=> $post_data['product_name'],
	            	'description' 	=> $post_data['description'],
	            	'amount' 	=> $post_data['amount'],
	            	'currency' 	=> $post_data['currency'],
	            	'category_id' 	=> $post_data['category_id'],
					'product_img' 	=> ($product_img)?base_url().$product_img:'',
					'status' 	=> $post_data['status'],
					'created_datetime' => date('Y-m-d H:i:s')
	            );
				$users = $this->db->insert('products', $insert_data);
				if(!empty($users)) {
					$response_code = '200';
					$response_message = "Products Added Successfully";
				} else {
					$response_code = '200';
					$response_message = "Something went wrong, Please try again";
				}
					
			} else {
				$response_code = '500';
				$response_message = "Product Name Already Exists";
			}
		} else {
			$response_code = '200';
			$response_message = "Input Field Missing";
		}
		$result = $this->data_format($response_code, $response_message, $data);
		$this->response($result, REST_Controller::HTTP_OK);
	}

	/** To Update Product Details - POST Method 
	 * @string Product Name
	 * @string Product Image
	 * @string Description
	 * @var Category Id
	 * @var Status 
	 */
	public function update_products_post()
	{
		$post_data = array();
		$post_data = $this->post();
		$data = array();

		if (!empty($post_data['id']) && !empty($post_data['product_name']) && !empty($post_data['description'])  && !empty($post_data['amount']) && !empty($post_data['currency']) && !empty($post_data['category_id']) && !empty($post_data['status'])) {

			$get_product_name = $this->api->get_product_name($post_data['id'], $post_data['product_name']);
			
			$product_image = $this->db->get_where('products', array('id'=>$post_data['id']))->row()->product_img;

			if($get_product_name == 0) {
				$uploaded_file_name = '';
	            if (isset($_FILES) && isset($_FILES['product_image']['name']) && !empty($_FILES['product_image']['name'])) {

	            	if (!is_dir('uploads/products')) {
			            mkdir('./uploads/products', 0777, TRUE);
			        }
	                $table_data1 = [];
		            $configfile['upload_path'] = FCPATH . 'uploads/products';
		            $configfile['allowed_types'] = 'gif|jpg|jpeg|png';
		            $configfile['overwrite'] = FALSE;
		            $configfile['remove_spaces'] = TRUE;
		            $file_name = $_FILES['product_image']['name'];
		            $configfile['file_name'] = time() . '_' . $file_name;
		            $image_name = $configfile['file_name'];
		            $image_url = 'uploads/products/' . $image_name;
		            $this->upload->initialize($configfile);
		            if ($this->upload->do_upload('product_image')) {
		                $img_uploadurl = 'uploads/categories' . $_FILES['product_image']['name'];
		                $val = 'uploads/products/' . $image_name;
		                $product_img = $val;
		            } else {
		            	$product_img = $product_image;
		            }
	            } else {
	            	$product_img = $product_image;
	            }

	            $update_data = array(
	            	'product_name' 	=> $post_data['product_name'],
	            	'description' 	=> $post_data['description'],
	            	'amount' 	=> $post_data['amount'],
	            	'currency' 	=> $post_data['currency'],
	            	'category_id' 	=> $post_data['category_id'],
					'product_img' 	=> ($product_img)?base_url().$product_img:'',
					'status' 	=> $post_data['status'],
					'updated_datetime' => date('Y-m-d H:i:s')
	            );
	            $this->db->where('id', $post_data['id']);
				$users = $this->db->update('products', $update_data);
				if(!empty($users)) {
					$response_code = '200';
					$response_message = "Product Details Updated Successfully";
				} else {
					$response_code = '200';
					$response_message = "Something went wrong, Please try again";
				}
			} else {
				$response_code = '203';
				$response_message = "Product Name Already Exists";
			}
		} else {
			$response_code = '200';
			$response_message = "Input Field Missing";
		}
		$result = $this->data_format($response_code, $response_message, $data);
		$this->response($result, REST_Controller::HTTP_OK);
	}

	/** To Add Rating fot Products - POST Method 
	 * @var Product Id
	 * @var User Id
	 * @var Ratings
	 * @string comments
	 */
	public function add_reviews_post()
	{
		$post_data = array();
		$post_data = $this->post();
		$data = array();

		if (!empty($post_data['product_id']) && !empty($post_data['user_id'])  && !empty($post_data['ratings']) && !empty($post_data['comments'])) {

			$get_rating = $this->api->get_rating($post_data['product_id'], $post_data['user_id']);
			if($get_rating == 0) {
	            $insert_data = array(
	            	'product_id' 	=> $post_data['product_id'],
	            	'user_id' 	=> $post_data['user_id'],
	            	'ratings' 	=> $post_data['ratings'],
					'comments' 	=> $post_data['comments'],
					'created_datetime' => date('Y-m-d H:i:s')
	            );
				$ratings = $this->db->insert('reviews', $insert_data);
				if(!empty($ratings)) {
					$response_code = '200';
					$response_message = "Ratings Added Successfully";
				} else {
					$response_code = '200';
					$response_message = "Something went wrong, Please try again";
				}
					
			} else {
				$response_code = '500';
				$response_message = "Ratings Already Updated";
			}
		} else {
			$response_code = '200';
			$response_message = "Input Field Missing";
		}
		$result = $this->data_format($response_code, $response_message, $data);
		$this->response($result, REST_Controller::HTTP_OK);
	}

	/** To Get All Ratings Details */
	public function ratings_get()
	{
		$post_data = array();
		$post_data = $this->get();
		$data = array();
		$ratings_data = array();
			$ratings = $this->db->order_by('id','DESC')->get('reviews')->result_array();

			foreach($ratings as $rating) {
				$user_name = $this->db->get_where('users', array('id'=>$rating['user_id']))->row()->username;
				$product_name = $this->db->get_where('products', array('id'=>$rating['product_id']))->row()->product_name;
				$ratings_data['id'] = $rating['id'];
				$ratings_data['product_name'] = $product_name;
				$ratings_data['user_name'] = $user_name;
				$ratings_data['reviews'] = $rating['ratings'];
				$ratings_data['comments'] = $rating['comments'];

				$rating_data[] = $ratings_data;
			}
		if(!empty($ratings)) {
			$data = $rating_data;
			$response_code = '200';
			$response_message = "Ratings Listed Successfully";
		} else {
			$response_code = '200';
			$response_message = "Ratings List Not Found";
		}
		$result = $this->data_format($response_code, $response_message, $data);
		$this->response($result, REST_Controller::HTTP_OK);
	}

	/** To Get All Ratings Details */
	public function get_featured_products_get()
	{
		$post_data = array();
		$post_data = $this->get();
		$data = array();
		$all_product_data = array();
			$featured_datass = $this->api->get_featured_datas();

			foreach($featured_datass as $featured_data) {
				$featured_datas['product_id'] = $featured_data['id'];
				$featured_datas['product_name'] = $featured_data['product_name'];
				$featured_datas['product_image'] = ($featured_data['product_img'])?base_url().$featured_data['product_img']:'';
				$featured_datas['description'] = $featured_data['description'];
				$featured_datas['amount'] = $featured_data['amount'];
				$featured_datas['currency'] = $featured_data['currency'];
				$featured_datas['user_name'] = ($featured_data['username'])?($featured_data['username']):'';
				$featured_datas['category_name'] = $featured_data['category_name'];
				$featured_datas['reviews'] = ($featured_data['ratings'])?$featured_data['ratings']:'';
				$featured_datas['comments'] = ($featured_data['comments'])?$featured_data['comments']:'';
				$featured_datas['status'] = $featured_data['status'];

				$all_product_data[] = $featured_datas;
			}
		if(!empty($featured_datass)) {
			$data = $all_product_data;
			$response_code = '200';
			$response_message = "Featured Products Listed Successfully";
		} else {
			$response_code = '200';
			$response_message = "Featured Products List Not Found";
		}
		$result = $this->data_format($response_code, $response_message, $data);
		$this->response($result, REST_Controller::HTTP_OK);
	}


}
